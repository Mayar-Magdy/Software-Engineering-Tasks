/// output text to user 
//1- using alert
//alert('Hello from External File')
//2- using document.write
// document.write("<p><b>Welcome SWF Track!!!</b></p>")
// document.write("<h1>Bani Suef</h1>")
///////////////////////////////////////////////////////
/// variables /////
/// Loose Typing 
//var X; //decleration
//document.write(X)//undefined
// X=6;
// X='Sarah'
// document.write(X);

///Hoisteing ==> makes all declerations to the top of file ( first thing in file)
// Y=6;
// document.write(Y);
// var Y;

// //let T=8;//global

// {
//     var K=9; //global
//     let M=6; //local

//     console.log(M)//6
//     console.log(K)//9
// }
//console.log(M)//error
//console.log(K) //9
//console.log(T);//8

//let not hoisted 
//console.log(T);//error
//let T=8;

//const PI; //error
//const PI=3.14 //must declare + initialize at once 
//PI=4;//error , cannot re-assign const variable
////////////////////////////////////////////////////////////////////////////////////////





