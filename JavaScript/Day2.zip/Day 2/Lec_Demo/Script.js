///// Operators ////
/// Postfix vs prefix
 //var x=0;
// //console.log(++x)//1
// //console.log(x++)//0 
//y=x++; ///==> y=x; x=x+1
//y=++x; ///==> x=x+1; y=x
// console.log(y)//0 (x++), 1(++x)
// console.log(x);//1
// console.log(y);
/////////////////////////////////////////
// var x=1, y="1";
// console.log(x==y) //values only
// console.log(x===y) //values + Datatype
/////////////////////////////////////////////
///Trenary Operator 
// var Age =19
// var Result= (Age>21)? "Accepted":"Rejected"
// console.log(Result);
// console.log((Age>21)? "Accepted":"Rejected")
/////////////////////////////////////////////////
//// typeof ==> returns data type of the variable 
// var X=1;
// console.log(typeof(X))
// X="A"
// console.log(typeof(X))
/////////////////////////////////////////////////
///Coercion
// var x=1, y=1
// console.log(x+y)//2
//var x=1, y="1", z=2
// console.log(x+y)//11 ==>concatenation , 
// var FirstName="Sarah", LastName="Refaie"
// console.log(FirstName+LastName)//SarahRefaie
// console.log(FirstName-LastName)//NaN ==> not a number 
// console.log(x+z+y)//31
// console.log(y+x+z)//112 ==> convert number to string
//console.log(x-y)//0 ==> cannot sub string ==> convert string to number 
////////////////////////////////////////////////////////////////////////
//Switch
// var letter='a';
// switch(letter){
//     case 'A':
//     case 'a':    
//         console.log("Excellent")
//         break;
//     case 'B':
//         console.log("V.Good")
//         break;
//     default:
//         console.log("failed")
        
// }
////////////////////////////////////////////
///Loops:
var start=0, end=10
// for(let i=start; i<end; i++)
// {
//     if(i==4)
//         continue; //==> skipt this iteration
//     if(i==7)
//         break; //==> out of loop
//         console.log(i);
// }

// while(start<end){
//     console.log(start);
//     start++;
// }

// do{
//     console.log(start);
//          start++;
// }while(start<end)
/////////////////////////////////////////////////////////////
//// Functions /////
// function Sum(x,y)
// {
//     var n; //local
//      A="jjj"; //var A
    
// }

//console.log(n);//error
//console.log(A);
// Sum(1,1)
// B="kk"; //global, var
// console.log(B);

// function Sum2()
// {
//     console.log(B);
   
// }
// Sum2()

// function Sum(x,y)
// {
//     //console.log(x+y)
//     return x+y
// }

// var Result =Sum(2,2);
// console.log(Result)
/////////////////////////////////////////////////
///Dialog Boxes ////
// var Name= prompt("Enter Your name:")
// console.log(Name);

// var Confirmed = confirm("Are you sure?")
// console.log(Confirmed)
/////////////////////////////////////////////////
// function RegisterStudent(){
//     var Name=prompt("Enter your name");
//     var Age = prompt("Enter your age");

//     if(Name.length>3 && parseInt(Age)>21)
//     {
//         console.log("Accepted")
//        // document.write("Accpeted")
//     }
//     else
//     {
//         console.log("Rejected")
//        // document.write("Rejected")
//     }

// }
// ////////////////////
// var X=prompt("Enetr experssion")
// console.log(eval(X))
//////////////////////////////////////////////////////////////////////////////
///Errors
//synatx 
//console.lo("jhg")
//Runtime Error
// console.log(C)
// console.log("jhgfds")
// debugger;
// for(let i=0; i<5; i++){
//     console.log(i)
// }

// function TestDebugger(x,y){
//     debugger;
//     console.log(x+y)
// }
// TestDebugger(1,2)
///////////////////////////////////////////////////
///// Built in Objects ////
/// String Object:
var Str ="ITI Beni Suef Branch SWF"
//Prop
console.log(Str.length)//24
///1-  Methods manipulating the contents of the String
console.log(Str.charAt(1))//T, starts with 0 (index)
console.log(Str.indexOf("B"))//4, first match
console.log(Str.lastIndexOf("B"))//14, Last match 
console.log(Str.substring(4,))//Beni Suef Branch SWF, end =last index
console.log(Str.substring(4,7))//Ben, 7 index not included 
console.log(Str)
console.log(Str.replace(/B/,"*"))//ITI *eni Suef Branch SWF, first match
console.log(Str.replace(/B/g,"*"))//ITI *eni Suef *ranch SWF, all match
console.log(Str.replace(/f/ig,"*"))//ITI Beni Sue* Branch SW*, all match, ignore case sinsitivty
////////////////////////////////////////////////////////////////
//2- Methods manipulating the appearance of the String 
document.write(Str.bold())
document.write(Str.toLocaleLowerCase())
console.log(Str.link("http://www.google.com"))

//3- Convert string to html link <a> tag
document.write(Str.link("http://www.google.com"))
/////////////////////////////////////////////////////////////////////////////////////////////////////////


