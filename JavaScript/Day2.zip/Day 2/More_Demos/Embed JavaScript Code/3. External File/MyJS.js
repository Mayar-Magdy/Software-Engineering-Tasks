function dosomething()
{
	alert ("Hello");
}

function dosomething1()
{
	document.write("welcome");
}

