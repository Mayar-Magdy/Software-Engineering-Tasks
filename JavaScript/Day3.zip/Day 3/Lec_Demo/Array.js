///Array
/// does not have fixed size
/// holds any data type 

//// declare and initialize array
//var arr = new Array('A','B','C');

// var arr=new Array();
// arr[0]="Ahmed"
// arr[1]="Mohamed"
// arr[2]="Aya"
//arr[1]="Ali" //update (re-assign )

// var arr3=[]
// arr3[0]=1
// arr3[1]="Ali"

// console.log(arr)
// document.write(arr)//Ahmed,Mohamed,Aya
////////////////////////////////////////////
var arr=new Array();
arr[0]="Ahmed"
arr[1]="Mohamed"
arr[2]="Aya"

// //Proprties
// console.log(arr.length)//3 , size of array

// //Methods
// console.log(arr.join("*"))//Ahmed*Mohamed*Aya
// console.log(arr.reverse())//will affect the original array
// console.log(arr) //Aya,Mohamed,Ahmed
// arr.push("Ali") //add in last index
// console.log(arr)
// console.log(arr.pop())//Ali, remove last index
// console.log(arr.shift())//Aya, remove first index
// arr.unshift("D")//add in first index 
// console.log(arr)
// console.log(arr.sort())

// var aar2 = new Array(1,12,4,21,15,9)
// console.log(aar2.sort()) //alphanumeric
/////////////////////////////////////////////////
/// Looping Array 
//for
// for(let i=0; i<arr.length; i++){
//     document.write(arr[i]+"<br>");
// }

//for in ==> i --> counter (index)
// for(let i in arr){
//     document.write("index "+i+"= "+ arr[i]+"<br>");
// }

// // for of ==> i --> value
// for(let i of arr){
//     document.write(i+"<br>");
// }
//////////////////////////////////////////////////////

///Associative Array: (Key,value)
// var Students = new Array();
// Students["Ahmed"]=3;
// Students["Ali"]=3.7
// Students["Mayar"]=4
// //Students["Ahmed"]=3.5; //update 

// console.log(Students["Ahmed"])

// //use only for in
// for(let S in Students)
// {
//     document.write(S+" = "+Students[S]+"<br>")
// }
//////////////////////////////////////////////////////////

