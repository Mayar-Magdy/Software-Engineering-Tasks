/// JSON ==> search
//Literal Object
var Student={
    ID:1,
    Name:"Sarah",
    Address:"Minia",
    Display:function(){
        return "ID= "+this.ID+this.Name+this.Address;
        //this required
    }
}

// document.write(Student.ID)
// document.write(Student.Name)
// document.write(Student.Display())
//////////////////////////////////////////////////////

