#include <iostream>

using namespace std;

int arr[5];
int ToS=0;

int Push(int data)
{
    int retVal=0;
    if(ToS<5)
    {
      arr[ToS]=data;
      ToS++;
      retVal=1;
    }
    return retVal;
}

int Pop(){
   int retVal=-1;
   if(ToS>-1)
   {
       ToS--;
       retVal=arr[ToS];
   }

   return retVal;
}



struct Node{
  int Data;
  Node *pPrev;
};
Node *pTail=NULL;

Node* createNode(int d){
   Node *ptr;
   ptr=new Node;
   if(ptr!=NULL)
   {
       ptr->Data=d;
       ptr->pPrev=NULL;
   }
   return ptr;
}

  int Push(int data)
  {
      int retVal=0;
      Node *pPtr;
      pPtr=createNode(data);
      if(pPtr!=NULL)
      {
          if(pTail==NULL) // No List
          {
              pTail=pPtr;
          }
          else{ // There is List

            pPtr->pPrev=pTail;
            pTail=pPtr;
          }
      }
  }

 int Pop()
  {
      int retVal=0;
      Node *pTemp;
      pTemp=pTail;
      if(pTail!=NULL)
      {
          pTail=pTail->pPrev;
          retVal=1;
      }

        delete pTemp;

        return retVal;
  }

int main()
{

    cout<<Push(10);
    cout<<Push(20);





    return 0;
}
