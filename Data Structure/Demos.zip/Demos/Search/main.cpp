#include <iostream>

using namespace std;

  int linearSearch(int arr[],int SizeofArray,int data)
  {
      int loc=-1;
      int i=0;
      while(loc==-1&&i<SizeofArray)
      {
          if(arr[i]==data)
          {
              loc=i;
          }
          else{
            i++;
          }
      }
      return loc;
  }
int main()
{
    int n=8;
    int arr[n];
    arr[0]=12;
    arr[1]=13;
    arr[2]=7;
    arr[3]=11;
    arr[4]=14;
    arr[5]=3;
    arr[6]=9;
    arr[7]=5;

    int res;
    res=linearSearch(arr,n,14);

    if(res==-1)
    {
        cout<<"Not Founded"<<endl;
    }
    else
    {
        cout<<"Founded"<<"Your Index is :"<<res;

    }

    return 0;
}
