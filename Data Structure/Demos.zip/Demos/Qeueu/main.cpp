#include <iostream>

using namespace std;

 int arr[5];
 int ToQ=0;

 int Enqueue(int data)
 {
     int retVal=0;
     if(ToQ<5)
     {
         arr[ToQ]=data;
         ToQ++;
         retVal=1;
     }
     return retVal;
 }

 int Dequeue()
 {
     int retVal=-1;   // No Delete Any Element
     if(ToQ>=0)
     {
         retVal=arr[0];
         for(int i=0;i<ToQ-1;i++)
         {
            /* arr[0]=arr[1]
             arr[1]=arr[2]
             arr[2]=arr[3]
             arr[3]=arr[4]
             */
             arr[i]=arr[i+1];
         }
         ToQ--;
     }
     return retVal;
 }


 struct Node {

    int Data;
    Node *pNext;
 };

 Node *pHead=NULL;
 Node *pTail=NULL;

Node* createNode(int d){
   Node *ptr;
   ptr=new Node;
   if(ptr!=NULL)
   {
       ptr->Data=d;
       ptr->pNext=NULL;
   }
   return ptr;
}


 int EnQueue(int data)
 {

     int  retVal=0;
     Node *pPtr=createNode(data);
     if(pPtr!=NULL)
     {
         if(pHead==NULL)
         {
             pHead=pTail=pPtr;
         }
         else
         {
             pTail->pNext=pPtr;
             pTail=pPtr;
         }
         retVal=1;
     }

     return retVal;
 }

 int Dequeue()
 {
     int retVal=0;
     Node *pPtr;
     pPtr=pHead;
     if(pHead!=NULL)
     {
         if(pHead==pTail)  // One Node in List
         {
            pHead=pTail=NULL;
         }
         else{   // More Than one Node in List

            pHead=pHead->pNext;
         }
         delete pPtr;
         retVal=1;
     }

     return retVal;
 }
int main()
{

    //arr[0]=10;
    //arr[1]=20;


    Enqueue(10);
    Enqueue(100);
    Enqueue(20);
    Enqueue(300);
     Enqueue(500);


    cout<<"Add To Array using Queue"<<endl;
    for(int i=0;i<5;i++)
    {
        cout<<arr[i]<<" ";
    }

    cout<<endl;
    cout<<"Delete From Array using Queue"<<endl;
    Dequeue();
        for(int i=0;i<4;i++)
    {
        cout<<arr[i]<<" ";
    }

     cout<<endl;
    cout<<"Add To Array using Queue"<<endl;
    Enqueue(900);
      for(int i=0;i<5;i++)
    {
        cout<<arr[i]<<" ";
    }

     cout<<endl;
    cout<<"Delete From Array using Queue"<<endl;
    Dequeue();
        for(int i=0;i<4;i++)
    {
        cout<<arr[i]<<" ";
    }

    return 0;
}
