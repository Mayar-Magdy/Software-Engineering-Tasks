#include <iostream>

using namespace std;

int main()
{
    int n=8;
    int arr[n];
    arr[0]=12;
    arr[1]=13;
    arr[2]=7;
    arr[3]=11;
    arr[4]=14;
    arr[5]=3;
    arr[6]=9;
    arr[7]=5;

    cout<<"Array Before Sorting"<<endl;
    for(int i=0;i<8;i++)
    {
        cout<<arr[i]<<" ";
    }
    int temp;

    // Bubble Sorting
    for(int j=0;j<n-1;j++)
    {
        for(int i=0;i<n-1-j;i++)
        {
           if(arr[i]>arr[i+1])
           {
               temp=arr[i];
               arr[i]=arr[i+1];
               arr[i+1]=temp;
           }
        }
    }

    cout<<endl;
    cout<<"Array After Sorting"<<endl;
    for(int i=0;i<8;i++)
    {
        cout<<arr[i]<<" ";
    }
    return 0;
}
