#include <iostream>

using namespace std;

// 1) Create Node
struct Node{
  int Data;
  Node *pNext;
  Node *pPrev;
};

// 2) Create Head & Tail

Node *pHead=NULL;
Node *pTail=NULL;


Node* createNode(int d){
   Node *ptr;
   ptr=new Node;
   if(ptr!=NULL)
   {
       ptr->Data=d;
       ptr->pNext=ptr->pPrev=NULL;
   }
   return ptr;
}


// 3) Add Node to List "at the End of List"
int Add(int data){
    int retVal=0;
    Node *ptr;
    ptr=createNode(data);
    if(ptr!=NULL)
    {
        retVal=1;
        if(pHead==pTail)  // List May be Contain One Node or Not Nodes
        {
            if(pHead==NULL)  // No List
            {
                pHead=pTail=ptr;
            }
            else   // There is Node
            {
              pTail->pNext=ptr;
              ptr->pPrev=pTail;
              pTail=ptr;
            }
        }
        else{

              pTail->pNext=ptr;
              ptr->pPrev=pTail;
              pTail=ptr;
        }
        return retVal;
    }
}

// 4) Insert Node to List   "First / Middle / Last"

int Insert(int data,int position)
{
    int retVal=0;
    Node *pPtr,*pTemp;
    pPtr=createNode(data);
    if(pPtr!=NULL)
    {
        retVal=1;
        if(pHead==NULL)  //No List
        {
            pHead=pTail=pPtr;
        }
        else{
            if(position==0)  // Add Node at The First Node in List
            {
                pPtr->pNext=pHead;
                pHead->pPrev=pPtr;
                pHead=pPtr;
            }
            else{

                pTemp=pHead;
                for(int i=0;i<position-1&&pTemp!=NULL;i++) // position =2  // i=2
                {
                    pTemp=pTemp->pNext;
                }
                if(pTemp==pTail||pTemp==NULL)
                {
                    // Add Node at The end of List
                     pTail->pNext=pPtr;
                     pPtr->pPrev=pTail;
                     pTail=pPtr;

                     //Add();
                }

                else{  // Middle or at the specific Position

                 pTemp->pNext->pPrev=pPtr;
                 pPtr->pNext=pTemp->pNext;
                 pPtr->pPrev=pTemp;
                 pTemp->pNext=pPtr;
                }

            }

        }
    }
   return retVal;
}


  // 5) Delete Node from List "First / Middle / Last"
 int Delete(int loc)
 {
      int retVal=0;
      Node *pTemp;
      if(pHead!=NULL) //There is List
      {
          pTemp=pHead;
          if(loc==0)
          {
              pHead=pHead->pNext;
             if(pHead==NULL)  // List Contain one Node
             {
                pTail=NULL;
             }
             else
             {
                 pHead->pPrev=NULL;
             }
             retVal=1;
             delete pTemp;
          }
          else
          {
              for(int i=0;i<loc&&pTemp!=NULL;i++)
              {
                  pTemp=pTemp->pNext;
              }
              if(pTemp!=NULL)
              {
                  if(pTemp==pTail)  // Delete last Node
                  {
                      pTail=pTail->pPrev;
                      pTail->pNext=NULL;
                  }
                  else
                  {
                      pTemp->pPrev->pNext=pTemp->pNext;
                      pTemp->pNext->pPrev=pTemp->pPrev;
                  }
              }
          }
      }

      delete pTemp;
      return retVal;

 }

  // 6) Display List
  void Display()
  {
      Node *pTemp;
      pTemp=pHead;
      while(pTemp!=NULL)
      {
          cout<<pTemp->Data<<endl;
          pTemp=pTemp->pNext;
      }
  }



  // 7) Search on Node

    Node* Search(int data)
    {
          Node *pTemp;
          pTemp=pHead;

        if(pHead!=NULL)  // There is List
        {
            while(pTemp!=NULL&&pTemp->Data!=data)
            {
               pTemp=pTemp->pNext;

            }
        }
        return pTemp;
    }

    // 8) Free List
    void FreeList()
    {
        Node *pTemp;
        while(pHead!=NULL)  // There is List
        {
            pTemp=pHead;
            pHead=pHead->pNext;
            delete pTemp;
        }
        pTail=NULL;
    }



int main()
{

 // Node *pNewNode;

    //pNewNode=createNode(10);
    //cout<<pNewNode->Data;

    Insert(10,0);
    Insert(20,1);
    Insert(30,2);
    Insert(40,3);
    Add(50);
    Add(60);

    cout<<"Display List"<<endl;
    Display();

    Node *ptr=Search(100);
    //cout<<ptr<<"**********NULL*********"<<endl;
    if(ptr==NULL)
    {
        cout<<"Not Found"<<endl;
    }
    else
    {
        cout<<"Founded: Your Data is "<<ptr->Data<<endl;
    }


    return 0;
}
