--- Alter , drop
----- add new col
alter table Book
add Gener varchar(20) not null 

----- drop col
alter table Book
drop column Gener

--- add new constraint
alter table Book
add constraint Gener_DF default 'sci-fi' for Gener

---------------------------------------------------------