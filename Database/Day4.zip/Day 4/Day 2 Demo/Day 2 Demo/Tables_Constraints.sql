------ DDL & Constraints ----
--use LibrarySystem

create table Author
(
	ID int primary key identity(1,1), -- identity(Start value, Incremental value)
	[Name] nvarchar(30) not null,
	AuthorAddress nvarchar(50) default 'Beni suef' ---by default allow null
)


create table Publisher 
(
	Name nvarchar(20),
	--PAddress nvarchar(50) check (PAddress ='Minia'or PAddress='Beni suef' or PAddress='Cairo'),
	PAddress nvarchar(50) check (PAddress in ('Minia','Beni suef','Cairo')), --multipule OR condition

	-- constraintKeyword ConstrainName ConstraintType ConstraintsCols
	constraint Publisher_PK primary key ([Name]),
	--constraint chk_PAddress check (PAddress in ('Minia','Beni suef','Cairo'))

	--- composit PK
	--constraint Publisher_PK primary key ([Name],PAddress)
)

create table Book
(
	ISBN int primary key,
	Title nvarchar(30) not null,
	isAvailable bit,--default 0
	PName nvarchar(20) null, --foreign key references Publisher ([Name]),

	constraint FK_Book_Publisher foreign key (PName) references Publisher ([Name])
)


create table Publisher_Phone
(
	Phone char(11) check(len(Phone)=11) not null,
	PName nvarchar(20) not null,

	--- composite PK
	constraint PK_Publisher_Phone primary key (Phone,PName),
	constraint FK_PublisherPhone_Publisher foreign key (PName) references Publisher([Name])


)
/*
	==>PK vs UQ
		==> primary Key :
				1- ONLY ONE PK for table
				2- Not null + Unique 
		==> unique key
				1- Many UQ for table
				2- Allow ONLYONE NULL value
				3- Uniqueness of value
*/
----------------------------------------
--- Alter , drop
----- add new col
alter table Book
add Gener varchar(20) not null 

----- drop col
alter table Book
drop column Gener

--- add new constraint
alter table Book
add constraint Gener_DF default 'sci-fi' for Gener

---------------------------------------------------------