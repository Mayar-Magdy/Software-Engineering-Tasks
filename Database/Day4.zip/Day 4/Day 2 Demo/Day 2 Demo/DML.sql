-------- DML -------------
--- Insert ==> add new data ---

--- insert inside all cols (Order)
insert into Publisher 
values('A','Minia')


insert into Publisher 
values('A','Minia'),('B','Beni suef'),('C','Cairo') ---error, cannot have same value for PK

--- insert many rows , insert based on constructor 
insert into Publisher 
values('D','Minia'),('B','Beni suef'),('C','Cairo') ---error, cannot have same value for PK

--- error, FK
insert into Book
values(111, 'B1',0,'X','Adventure')

--- error, no of values less than no of cols 
insert into Book
values(111, 'B1',0,'X')

--- error, title not null and it's not included with the inserted col
insert into Book(ISBN,PName)
values(111, 'B1')


insert into Book(ISBN,PName,Title)
values(111,'A','B1')

-- using default values
insert into Book
values(555,'B2',0,'B',default)

-- insert null value
insert into Book
values(789,'B2',null,'B',default)

--- insert with identity
insert into Author 
values('A1','Minia')

--- cascade ==> self study 
-----------------------------------------------------
---- update ---

--- all rows 
update Book
set PName='B'

---- based on condition ==> some rows 
update Book
set PName='A'
where Gener='Adv'

update Author 
set AuthorAddress ='Alex'
where ID >3
------------------------------------------
--- Delete 

--remove all data from all rows 
delete from Author

delete from Author
where ID=5

--- trunctae
truncate table Author 
--------------------------
/* 
	Delete Vs Drop Vs Truncate 
		==> Drop ---> Remove structure 
		==> Delete ---> Data ONLY 
				   ---> Can use where 
				   ---> can use rollback ( can undo delete)

		==> Truncate ---> Data ONLY 
					 ---> can not use where 
					 ---> all rows 
				     ---> can not use rollback ( cannot undo delete) (execpet inside transaction)

*/
-------------------------------------------------------------------------------------------------------
/* 
	Lec Summary:
		===> Creating tables 
		===> Constraints
				===> PK
				===> FK
				===> Not null
				===> UQ
				===> Check
				===> Default
		===> Alter
		===> Drop
		===> Insert
		===> Update
		===> Delete

	Next Lec:
		===> Select
*/
---------------------------------------------------------------------












