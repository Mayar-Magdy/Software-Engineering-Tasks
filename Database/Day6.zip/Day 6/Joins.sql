-------------- Joins -------
---- Cross Join ---> not used 
select E.Name , D.Name 
from Employee E cross join Department D
-----------------------------------------
---- inner join ----
select E.Name , D.Name 
from Employee E inner join Department D
on E.DeptID=D.ID

--- different synatx
select D.Name , M.MgName 
from Department D , Manager M
where D.MGrID=M.ID 
-----------------------------------
--- Left Outer Join ---

select E.Name'EmpName' , D.Name 'Dept Name' 
from Employee E left outer join Department D
on E.DeptID=D.ID

---- Right Outer Join
select E.Name 'EmpName' , D.Name 'Dept Name'
from Employee E right outer join Department D
on E.DeptID=D.ID

---- Full outer Join
select E.Name 'EmpName' , D.Name 'Dept Name'
from Employee E full outer join Department D
on E.DeptID=D.ID
------------------------------------------------------
---- self join
select E.FName 'EmpName',S.FName 'SupName'
from Employee E, Employee S
where E.SupID=S.EmpNo

---- Logical Error ==> unexpected result ( wrong result)
select E.FName 'EmpName',S.FName 'SupName'
from Employee E, Employee S
where E.EmpNo=S.SupID
--------------------------------------------------------------


