------------ Schema ==> Security  ------

create schema NewSchema 

--- create new table inside newschema 
create table NewSchema.Emp
(
	ID int primary key 
)

--- error, will search inside dbo only 
insert into Emp
values(1)

-- must use it with schema name
insert into NewSchema.Emp
values(1)

--- table names unique ==> schema scope 
create table Person.Emp
(
	ID int primary key 
)

---- to tranfer table from one schema to another
alter schema dbo 
transfer Person.Emp
----------------------------------------------------------










