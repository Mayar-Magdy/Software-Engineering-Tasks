----------- DQL ===> Select (get data)-----
--- select all column with all rows 
select * from Production.Product

--- part of table ( specific cols ) 
select Name from Production.Product

--- with condition 
select Name, Color from Production.Product
where Color is not null

--- different values 
select distinct Color from Production.Product

select distinct Color from Production.Product
where Color is not null

---- concatenation + Alias 
select Name +' ==> '+  ProductNumber as 'Product Code'
from Production.Product

--- alias ==> query scope
select Name 'Product Name'
from Production.Product
------------------------------
--- order by one col
select ProductID, Name, ListPrice
from Production.Product
order by ListPrice desc 

--- order by many cols 
---> check the first incase found similar values ==> will order by second col
select ProductID, Name, ListPrice, SafetyStockLevel
from Production.Product
order by ListPrice desc , SafetyStockLevel asc

---- where + order by 
select ProductID, Name, ListPrice, SafetyStockLevel
from Production.Product
where ListPrice >500
order by ListPrice desc
--------------------------------------------------------
--- select first no of rows 
select top(4) Name, ListPrice
from Production.Product
order by ListPrice desc 

select top(2) Name, ListPrice
from Production.Product

---> top with ties ==> self study 
---> Limit ==> self study 
--------------------------------------
---- like operator 
--- search Name == B value 
select Name from Production.Product
where Name ='B'

select Name from Production.Product
where Name like '%B%'

select Name from Production.Product
where Name like '[A-h]%'
-------
/* 
	'_' ===> One Char Only 
	'%' ===> Zero or more 
	'[ahm]%' ===> starts with a or h or m 
	'[a-h]%' ===> range from a to h 
	'%[%]%' ===> contians % as char 
	'%[_]%' ===> contains _ as char 
*/
----------------------------------------------------------------
--- Logical Operators ==> AND , OR , NOT 
select Name, Color
from Production.Product
where Color = 'Black' or Color = 'Silver' or Color='Yellow'

---- IN ==> multiple OR 
select Name, Color
from Production.Product
where Color in ('Black','Silver','Yellow')

--- not ==> in, between and , .....
select Name, Color
from Production.Product
where Color not in ('Black','Silver','Yellow')

select Name , Color , ListPrice 
from Production.Product
where ListPrice >500 and ListPrice <3000
order by ListPrice

--- between ==> range of values
select Name , Color , ListPrice 
from Production.Product
where ListPrice between 500 and 3000
order by ListPrice
--------------------------------------------------
---- Arthimetic Operators 
select Name, ListPrice , (ListPrice*10) as 'After raise'
from Production.Product
-----------------------------------------------------------
--- Aggeregate Functions

---> no of rows 
select COUNT(*)
from Production.Product

select COUNT(ProductID)
from Production.Product

---- null not included 
select COUNT(Color) ' no. of products with color'
from Production.Product

select COUNT(*) as 'No of Products' , Avg(ListPrice) 'Average Price', Max(ListPrice) 'Max Price'
from Production.Product
-----------------------------------------------------------------------------------------------------------------
---- Group by 
select Color ,Count(ProductID)
from Production.Product
group by Color 

--- Color	|No of Products
--- Black	|5
--- Yellow	| 10

---- Error , color must be inside group by 
select Color ,Count(ProductID)
from Production.Product

---- group by multi cols 
----> LOogic ==> every color with each size in different group 
select Color, Count(SafetyStockLevel) 'Stock Level', Size
from Production.Product
group by Color, Size

--- Color	|Size	|StockLevel
---Black	|L		|3
---Black	|30		|5
---Red		|30		|6
---Red		|L		|90
----------------------------
---- error, 
select Color, Max(ListPrice) 'Max Price', Size
from Production.Product
where Max(ListPrice) >2000
group by Color, Size

---- having 
select Color, Max(ListPrice) 'Max Price', Size
from Production.Product
group by Color, Size
having Max(ListPrice) >2000

--- having + where 
select Color, Max(ListPrice) 'Max Price', Size
from Production.Product
where Size in ('38','L','M','44')
group by Color, Size
having Max(ListPrice) >2000
order by Size

--- order by + having 
select Color, Max(ListPrice) 'Max Price', Size
from Production.Product
group by Color, Size
having Max(ListPrice) >2000
order by Size

/*
	Where vs Having 
		1- Having must with Aggregate fun
		2- Where must be with cols or values ( cannot be with aggregate fun)
		3- Havng must come after group by 
		4- where must come before group by 

--- syntax order 
	1- select 
	2- from 
	3- where 
	4- group by 
	5- having 
	6- order by

*/
--------------------------------------------------------------------
 /* Lec Summary:
		===> Schema 
		===> Select 
				===> all
				===> distict 
				===> top
				===> like
				===> alias
				===> aggeregate fun
				===> group by
				===> having
				===> order by
				===> in , between 
Next Lec:
		===> Joins 
		===> Sub Query 
		===> Union
		===> ERD & Mapping 
		===> Normalization
*/
---------------------------------------------------------


























