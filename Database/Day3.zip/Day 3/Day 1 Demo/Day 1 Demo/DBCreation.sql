------- DB Creation -------
--- will create DB with default files
--create database LibrarySystem
---------------------------------------

create database LibrarySystem2
on Primary --fileGroup
(
	name='LibDF1',
	Size=10MB,
	filegrowth=4MB,
	Maxsize=100MB,
	filename='C:\Program Files\Microsoft SQL Server\MSSQL14.MSSQLSERVER\MSSQL\DATA\LibDF1.mdf'
),
(
	name='LibDF2',
	Size=10MB,
	filegrowth=4MB,
	Maxsize=unlimited,
	filename='C:\Program Files\Microsoft SQL Server\MSSQL14.MSSQLSERVER\MSSQL\DATA\LibDF2.ndf'
),
filegroup SecondaryFG1
(
	name='LibDF3',
	Size=10MB,
	filegrowth=4MB,
	Maxsize=unlimited,
	filename='C:\Program Files\Microsoft SQL Server\MSSQL14.MSSQLSERVER\MSSQL\DATA\LibDF3.ndf'
)
Log on 
(
	name='LibLog',
	Size=10MB,
	filegrowth=6MB,
	Maxsize=unlimited,
	filename='C:\Program Files\Microsoft SQL Server\MSSQL14.MSSQLSERVER\MSSQL\DATA\LibLog.ldf'
)
----------------------------------------------------------------------------------------------------------------
------ Alter ==> Structure DDL
--- to add new filegroup
alter database LibrarySystem2 
add filegroup ThridFG

--- to add secondary file inside FG
alter database LibrarySystem2
add file 
(
	name='LibDF4',
	Size=10MB,
	filegrowth=4MB,
	Maxsize=unlimited,
	filename='C:\Program Files\Microsoft SQL Server\MSSQL14.MSSQLSERVER\MSSQL\DATA\LibDF4.ndf'

) to filegroup ThridFG
---------------------------------
--- Drop ==> DDL 
drop database LibrarySystem2
----------------------------------------------------------
/* 
	Lec Summary:
			==> DBMS 
			==> DB 
			==> DDL 
				==> create, alter,drop DB
				==>Files 
				==> Filegroups 
	Next Lec:
			==> DDL
				==>create,alter,drop Tables 
				==> Constraints 
*/






